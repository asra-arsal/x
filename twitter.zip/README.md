# X-AUTO

A Twitter automation tool built with Puppeteer.
