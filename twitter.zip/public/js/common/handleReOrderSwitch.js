const handleReOrderSwitch = (type, kind) => {
    window.open(`/${type}/re-order/${kind}`, '_blank');
};
